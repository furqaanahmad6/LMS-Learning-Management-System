/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.Statement;
/**
 *
 * @author ashar
 */
public class Tables {
     public static void main(String[] args)
     {
         try
         {
             Connection con = ConnectionProvider.getCon();
             Statement st = con.createStatement();
            st.executeUpdate("DELETE FROM marks;");
            // st.executeUpdate("create table Courses(ID int AUTO_INCREMENT primary key,courseid varchar(100) UNIQUE ,coursename varchar(50),coursecredit int ,userbatch varchar(50),courseinstructor varchar(100))");
             //st.executeUpdate("create table appuser(appuser_pk int AUTO_INCREMENT primary key,userRole varchar(20),name varchar(20),dob varchar(30),mobileNumber varchar(50),email varchar(100),username varchar(20),password varchar(30),address varchar(100),userbatch varchar(50))");
 //st.executeUpdate("create table Marks(ID int AUTO_INCREMENT primary key,courseid varchar(100),coursename varchar(50),username varchar(20),coursemarks double)");
 //  st.executeUpdate("create table Student(ID int AUTO_INCREMENT primary key,username varchar(20),coursename varchar(50))");
                         
//st.executeUpdate("insert into appuser (UserRole,name,dob,mobileNumber,email,username,password,address) values('Teacher','Osama','22,11,1997','03024441219','osama@gmail.com','osama','osama','Lahore')");
             JOptionPane.showMessageDialog(null, "Table Created Successfully");
         }
         catch(Exception e)
         {
             JOptionPane.showMessageDialog(null, e);
         }
     }
}
