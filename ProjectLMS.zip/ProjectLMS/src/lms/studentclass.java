/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lms;
import dao.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;

public class studentclass {
    private String selectedCourse;

    public void setSelectedCourse(String course) {
        selectedCourse = course;
    }

    public String getSelectedCourse() {
        return selectedCourse;
    }

    public void populateCourses(String tmusername, javax.swing.JComboBox<String> comboBox) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = ConnectionProvider.getCon();

            String userPrefix = tmusername.substring(0, 2);

            String query = "SELECT coursename FROM courses WHERE userbatch >= ?";
            preparedStatement = connection.prepareStatement(query);

            int minimumBatch = 2000 + Integer.parseInt(userPrefix);

            preparedStatement.setInt(1, minimumBatch);
            resultSet = preparedStatement.executeQuery();

            List<String> courseList = new ArrayList<>();
            while (resultSet.next()) {
                String courseName = resultSet.getString("coursename");
                courseList.add(courseName);
            }

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(courseList.toArray(new String[0]));
            comboBox.setModel(model);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        comboBox.addActionListener(e -> {
            selectedCourse = (String) comboBox.getSelectedItem();
        });
    }

    public boolean insertSelectedCourse(String username) {
        try {
            Connection connection = ConnectionProvider.getCon();
            PreparedStatement insertStatement = connection.prepareStatement("INSERT INTO student (username, coursename) VALUES (?, ?)");

            insertStatement.setString(1, username);
            insertStatement.setString(2, selectedCourse);

            int rowsInserted = insertStatement.executeUpdate();

            insertStatement.close();
            connection.close();

            return rowsInserted > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
