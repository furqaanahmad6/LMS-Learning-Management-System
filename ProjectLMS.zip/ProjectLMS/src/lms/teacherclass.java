/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lms;
import java.sql.ResultSet;
/**
 *
 * @author ashar
 */
public class teacherclass{
    
   /* teacherclass()
    {}
     public boolean umarks(String courseName,String username,double totalMarks)
     {
        teacherDAL server = new teacherDAL();
        boolean rows = server.addmarksToDatabase(courseName, username, totalMarks);
        if(rows)
            return true;
        else
            return false;
    }*/
   
     public boolean uploadMarks(String courseName, String username, double totalMarks) {
        teacherDAL server = new teacherDAL();
        return server.addMarksToDatabase(courseName, username, totalMarks);
    }
     
     
    public void populateUsernamesForCourse(String courseName, javax.swing.JComboBox jComboBox) {
        teacherDAL server = new teacherDAL();
        ResultSet rs = server.getUsernamesForCourse(courseName);

        try {
            while (rs.next()) {
                jComboBox.addItem(rs.getString("username"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
