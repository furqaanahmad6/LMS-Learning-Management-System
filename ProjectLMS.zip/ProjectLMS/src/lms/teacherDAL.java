/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lms;


import java.sql.PreparedStatement;
import dao.ConnectionProvider;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.ResultSet;


/**
 *
 * @author ashar
 */
public class teacherDAL{
/*
    public boolean addmarksToDatabase(String courseName,String username,double totalMarks)
   {   int rows;
           
        try
        {
            Connection con = ConnectionProvider.getCon();
            String query = "insert into marks (coursename,username, coursemarks) values (?, ?, ?, ?)";
            PreparedStatement statement = con.prepareStatement(query);
        
            statement.setString(2, courseName);
            statement.setString(3, username);
            statement.setDouble(4, totalMarks);
            rows = statement.executeUpdate();
            
        }
        catch(Exception e) 
        {
            rows=0;
           System.out.println("Error");
        }
        return rows > 0;
    }*/
     public boolean addMarksToDatabase(String courseName, String username, double totalMarks) {
        int rows = 0;
        try {
            Connection con = ConnectionProvider.getCon();
            String query = "SELECT * FROM marks WHERE coursename = ? AND username = ?";
            PreparedStatement selectStatement = con.prepareStatement(query);
            selectStatement.setString(1, courseName);
            selectStatement.setString(2, username);
            ResultSet resultSet = selectStatement.executeQuery();

            if (resultSet.next()) {
                // If the entry exists, update the total marks
                query = "UPDATE marks SET coursemarks = ? WHERE coursename = ? AND username = ?";
                PreparedStatement updateStatement = con.prepareStatement(query);
                updateStatement.setDouble(1, totalMarks);
                updateStatement.setString(2, courseName);
                updateStatement.setString(3, username);
                rows = updateStatement.executeUpdate();
            } else {
                // If the entry does not exist, insert a new row
                query = "INSERT INTO marks (coursename, username, coursemarks) VALUES (?, ?, ?)";
                PreparedStatement insertStatement = con.prepareStatement(query);
                insertStatement.setString(1, courseName);
                insertStatement.setString(2, username);
                insertStatement.setDouble(3, totalMarks);
                rows = insertStatement.executeUpdate();
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rows > 0;
    }

    
     
      public ResultSet getUsernamesForCourse(String courseName)
      {
        ResultSet rs = null;
        try {
            Connection con = ConnectionProvider.getCon();
            String query = "SELECT username FROM student WHERE coursename = ?";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, courseName);
            rs = statement.executeQuery();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rs;
    }
    
   
}